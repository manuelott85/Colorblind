﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlayer : MonoBehaviour
{
    Rigidbody2D myobj;
    public float moveForce = 20;
    public float jumpForce = 5;
    public float minVelocity = 0.5f;
    public string forceValueRL;

    public float XSlowFactor = 1;
    public float YSlowFactor = 1;
    public float maxYspeed = 20;
    public float maxXspeed = 20;
    //for Jumping 
    public string forceButtonA;

    SoundSource soundS;
    public AudioClip jumpSound;

    private bool m_isAxisInUse = false;
    // Use this for initialization
    void Start()

    {

        soundS = GetComponent<SoundSource>();
    }

    // Update is called once per frame
    void Update()
    {
        myobj = GetComponent<Rigidbody2D>();
        
       // Debug.Log(myobj.velocity.y);
        if (forceValueRL == ""  || forceButtonA =="")
        {
            return;
        }
        // Debug.Log("leftcollision "+GetComponent<grabFix>().getIsCollidingLeft().ToString());
        //Debug.Log( "rightcollsion " +GetComponent<grabFix>().getIsCollidingRight().ToString());
        //Moving Left and Right

        float forceValueNum = Input.GetAxis(forceValueRL);
        if (Input.GetAxis(forceValueRL) != 0 && GetComponent<grabFix>().getIsCollidingRight() == false && forceValueNum > 0  )
        {

            myobj.AddForce(new Vector2(forceValueNum * moveForce, 0));

           // Debug.Log("MOVE RIGHT ");
        }

        if (Input.GetAxis(forceValueRL) != 0 && GetComponent<grabFix>().getIsCollidingLeft() == false && forceValueNum < 0)
        {

            myobj.AddForce(new Vector2(forceValueNum * moveForce, 0));

            // Debug.Log("MOVE  LEFT");
        }

        //Jump

        if (Input.GetButton(forceButtonA) )
        {
                if (myobj.velocity.y < minVelocity && myobj.velocity.y > -minVelocity && GetComponent<grabFix>().getIsCollidingUp()==false)
                {
                myobj.AddForce(new Vector2(0,  jumpForce),ForceMode2D.Impulse);
                if (soundS != null && jumpSound != null)
                    soundS.playAudio(jumpSound, 0, transform.position, false);
                //Debug.Log("jump");

                m_isAxisInUse = true;
                }
        }
        // Handling Max Speed 

        if (myobj.velocity.x > maxXspeed)
        {
            myobj.velocity = new Vector2(maxXspeed, myobj.velocity.y);
        }
        else if (myobj.velocity.x < -maxXspeed)
        {
            myobj.velocity = new Vector2(-maxXspeed, myobj.velocity.y);
        }

        if (myobj.velocity.y > maxYspeed)
        {
            myobj.velocity = new Vector2(myobj.velocity.x, maxYspeed);
        }
        else if (myobj.velocity.y < -maxYspeed)
        {
            myobj.velocity = new Vector2(myobj.velocity.x, -maxYspeed);
        }

    }
    private void FixedUpdate()
    {
        myobj = GetComponent<Rigidbody2D>();
        myobj.velocity= new Vector2(myobj.velocity.x * XSlowFactor, myobj.velocity.y * YSlowFactor);
    }


}
